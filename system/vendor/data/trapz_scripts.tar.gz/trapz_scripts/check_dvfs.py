#!/usr/bin/python

import sys

VERSION = '0.2'

def getTimeDifference(event_1, event_2):
    """ Utility method to return the time interval between two events. """
    return (event_2.timestamp - event_1.timestamp)

def plotGraph(list_freq_and_time):
    try:
       import pylab as plt
    except ImportError:
       sys.stderr.write("This script requires matplotlib package\n")
       sys.stderr.write("Ubuntu: sudo apt-get install python-matplotlib\n")
       sys.stderr.write("Other platforms: see http://matplotlib.sourceforge.net/\n")
       sys.exit(1)

    timestamps = []
    frequencies = []
    count = 0
    totalTime = 0
    prevFreq = 0
    for n in xrange(0, len(list_freq_and_time)-1):
        dict_freq_and_time = list_freq_and_time[n]
        time = dict_freq_and_time['time']
        totalTime += time
        frequency =  dict_freq_and_time['frequency']
        timestamps.append(totalTime)
        frequencies.append(prevFreq)
        timestamps.append(totalTime)
        frequencies.append(frequency)
        prevFreq = frequency
        count += 1
        # plotting only 50 events , since it gets dense if all the events are plotted.
        if count > 50:
           break
    plt.plot(timestamps, frequencies)
    plt.xlabel('time (1/100th of s)')
    plt.ylabel('frequency (Hz)')
    plt.grid(True)
    plt.savefig('cpu.png')
    plt.show()


if __name__ == "__main__":
    from trapztool import SimpleTrapz
    from trapztool import TrapzEvent
    import argparse
    description = "Simple script to measure CPU frequency"
    parser = argparse.ArgumentParser(description=description,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('xmlfile', help='filename of XML-format TRAPZ log dump')
    args = parser.parse_args()
    trapzfile = args.xmlfile

    strapz = SimpleTrapz(trapzfile)

    cpu_freq_events = strapz.filterEvents("DVFS", "DVFSChangeFreq")
    print "Number of events : " + str(len(cpu_freq_events))
    if len(cpu_freq_events) <= 0:
       sys.exit(1)
    print "TotalTime : " + str(getTimeDifference(cpu_freq_events[0] , cpu_freq_events[(len(cpu_freq_events)-1)]))

    # The output dict_cpu_events map will be {"cpu_frequency_as_key" , "cumulative_duration_in_that_frequency_as_value"}
    dict_cpu_events = {}
    # data structure which holds list of dictionaires. The dictionary keys are 'frequency' and 'time interval in that frequency'
    # This list will be used for plotting.
    list_freq_and_time = []

    for n in xrange(0, len(cpu_freq_events)-1):
        event = cpu_freq_events[n]
        nextEvent = event
        if n < len(cpu_freq_events)-1:
           nextEvent =  cpu_freq_events[n+1]
        duration = getTimeDifference(event, nextEvent)
        dict_freq_and_time = {}
        dict_freq_and_time['frequency'] = event.e1
        dict_freq_and_time['time'] = event.timestamp
        if dict_cpu_events.has_key(event.e1):
           duration = duration + dict_cpu_events[event.e1]
           dict_cpu_events[event.e1] = duration
        else:
           dict_cpu_events[event.e1] = duration
        list_freq_and_time.append(dict_freq_and_time)

    totalTime = 0
    for key in sorted(dict_cpu_events.keys()):
        print "     Frequency  : " + str(key) + " Hz " + " duration : " + str(dict_cpu_events[key]) + " 10's of ms "
        totalTime +=   dict_cpu_events[key]
    print "TotalTime = ",totalTime
    plotGraph(list_freq_and_time)

