from statemachine import StateMachine

class TateFpsStateMachine(StateMachine):
    NAME = "TateFps"
    DESCRIPTION = "Calculate running FPS counter on Tate platform"

    # Add VCD trace counting occurances in last 1 sec
    COUNT_INTERVAL = 1

    def START__DssDriver_DssCompDelayedCBDisplayed(self, event):
        return StateMachine.FINISHED
